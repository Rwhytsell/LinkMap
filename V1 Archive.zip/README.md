# LinkMap

Web spider created as a summer project for educational purposes. Also for my ambition to map the internet.

# Planned Features

1. Multi-Threaded
2. User defined thread count and link search depth
3. Stores on SQL database
4. Creates a "map" from the database
